from flask import Flask, request, jsonify, render_template
from pymongo import MongoClient

app = Flask(__name__)

class MongoDB:
    def __init__(self, uri, db_name, collection_name):
        self.client = MongoClient(uri)
        self.db = self.client[db_name]
        self.collection = self.db[collection_name]

    def insert_rule(self, rule_data):
        self.collection.insert_one(rule_data)

    def get_rules(self):
        return list(self.collection.find())

class RulebaseApp:
    def __init__(self, db):
        self.db = db

    def save_rule(self, rule_data):
        self.db.insert_rule(rule_data)

    def get_all_rules(self):
        return self.db.get_rules()

# Initialize MongoDB connection
mongo_db = MongoDB('mongodb://172.16.105.132:27017/', 'Project1', 'Rulebase')
rulebase_app = RulebaseApp(mongo_db)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/rulebase', methods=['GET', 'POST'])
def rulebase():
    if request.method == "POST":
        try:
            # Extract and validate form data
            conditions = request.form.getlist('conditions')
            disease_codes = request.form.getlist('disease_codes')
            disease_name = request.form.get('disease_name')
            expiry_value = request.form.get('expiry_value')

            # Collect all condition data
            condition_data = []
            for i in range(len(conditions)):
                condition_type = conditions[i]
                condition = {
                    'type': condition_type,
                    'parameter': request.form.get(f'parameters-{i+1}'),
                    'unit': request.form.get(f'units-{i+1}'),
                    'min_value': request.form.get(f'min_values-{i+1}') if condition_type == 'range' else None,
                    'max_value': request.form.get(f'max_values-{i+1}') if condition_type == 'range' else None,
                    'operator': request.form.get(f'operators-{i+1}') if condition_type == 'comparison' else None,
                    'comparison_value': request.form.get(f'comparison_values-{i+1}') if condition_type == 'comparison' else None,
                    'age_min': request.form.get(f'age_min-{i+1}'),
                    'age_max': request.form.get(f'age_max-{i+1}'),
                    'gender': request.form.get(f'genders-{i+1}'),
                    'condition_operator': request.form.get(f'condition_operators-{i}') if i > 0 else None  # Capture operator between conditions
                }
                condition_data.append(condition)

            rule_data = {
                'conditions': condition_data,
                'disease_codes': disease_codes,
                'disease_name': disease_name,
                'expiry_value': expiry_value  # Store the expiry value
            }

            # Save to MongoDB
            rulebase_app.save_rule(rule_data)

            # Return a success message
            return render_template('rulebase.html', message="Rule saved successfully!", message_type="success")
        except Exception as e:
            # Return an error message
            return render_template('rulebase.html', message=f"An error occurred: {str(e)}", message_type="danger")
    else:
        # Handle GET request
        return render_template('rulebase.html')  # Render the rulebase.html template for GET requests

if __name__ == '__main__':
    app.run(debug=True)
